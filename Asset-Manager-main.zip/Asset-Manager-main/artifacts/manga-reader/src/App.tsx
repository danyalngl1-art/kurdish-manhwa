import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { Navbar } from './components/layout/Navbar';
import Home from './pages/Home';
import Browse from './pages/Browse';
import NovelDetail from './pages/NovelDetail';
import Reader from './pages/Reader';
import Profile from './pages/Profile';
import Coins from './pages/Coins';
import Shop from './pages/Shop';
import NotFound from './pages/not-found';

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/novels" component={Browse} />
      <Route path="/novel/:id" component={NovelDetail} />
      <Route path="/read/:id/:chapter" component={Reader} />
      <Route path="/profile" component={Profile} />
      <Route path="/coins" component={Coins} />
      <Route path="/shop" component={Shop} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <div dir="rtl" className="min-h-[100dvh] bg-background text-foreground pb-16 md:pb-0 md:pt-16 font-sans">
          <Navbar />
          <main className="w-full h-full">
            <Router />
          </main>
        </div>
      </WouterRouter>
      <Toaster theme="dark" position="top-center" dir="rtl" />
    </QueryClientProvider>
  );
}

export default App;
