import { Link, useLocation } from "wouter";
import { ShoppingBag, Home, User, BookOpen } from "lucide-react";
import { useUser } from "@/hooks/use-user";

export function Navbar() {
  const [location] = useLocation();
  const { user } = useUser();

  const navItems = [
    { href: "/", label: "پەڕەی سەرەکی", icon: Home },
    { href: "/novels", label: "مانهواکان", icon: BookOpen },
    { href: "/shop", label: "بازاڕ (Shop)", icon: ShoppingBag },
    { href: "/profile", label: "پڕۆفایل", icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#1a1a1a] border-t border-[#333] md:top-0 md:bottom-auto md:border-b md:border-t-0">
      <div className="max-w-7xl mx-auto px-4 md:px-10">
        <div className="flex items-center justify-between h-16">

          {/* Logo */}
          <Link href="/">
            <span className="font-bold text-xl tracking-tight text-primary cursor-pointer">
              LEGENDS KRD
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div className={`flex items-center gap-2 cursor-pointer transition-colors text-sm font-medium ${isActive ? 'text-primary' : 'text-gray-300 hover:text-primary'}`}>
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>

          {/* Coin Badge */}
          <Link href="/shop">
            <div className="flex items-center gap-2 bg-[#262626] border border-primary/30 px-3 py-1.5 rounded-full cursor-pointer hover:bg-[#333] transition-all">
              <span className="text-sm">🪙</span>
              <span className="font-bold text-primary text-sm">کۆین: {user.coins}</span>
            </div>
          </Link>
        </div>
      </div>

      {/* Mobile Nav - Bottom Tab Bar */}
      <div className="md:hidden flex justify-around items-center h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex flex-col items-center justify-center w-16 h-full gap-1 cursor-pointer transition-colors ${isActive ? 'text-primary' : 'text-gray-500 hover:text-primary'}`}>
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{item.label.split(" ")[0]}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
