export interface Chapter {
  id: string;
  novelId: string;
  chapterNumber: number;
  title: string;
  content: string;
  coinCost: number;
}

export interface Novel {
  id: string;
  title: string;
  cover: string;
  genre: 'action' | 'romance' | 'fantasy' | 'drama' | 'horror';
  description: string;
  isFree: boolean;
  author: string;
  status: 'ongoing' | 'completed';
}

import coverActionChain from "@assets/generated_images/cover_action_chain.jpg";
import coverFantasySystem from "@assets/generated_images/cover_fantasy_system.jpg";

export const NOVELS: Novel[] = [
  {
    id: "the-boxer",
    title: "The Boxer",
    cover: coverActionChain,
    genre: "action",
    description: "چیرۆکی کوڕێکی ناتەواو کە بوونی ئامادەی کوشتنی هەیە، بەڵام کە ئێگۆ لەگەڵیدا دەکەوێت، دەیگۆڕێت بۆ یەکەم جار لە ژیانیدا شور و مودیواتیک دەبێت و دەبێتە بۆکسەری بێهاوتا.",
    isFree: true,
    author: "JH",
    status: "ongoing"
  },
  {
    id: "questism",
    title: "Questism",
    cover: coverFantasySystem,
    genre: "fantasy",
    description: "لە جیهانێکدا کە سیستەمی کوێست دەسەڵاتی هەموو شتێکی دەگرێتەبەر، مرۆڤێک کە هیچ کوێستی نییە دەست دەکات بە گەڕان بە دوای مانای ژیانیدا لە نێوان تێکەڵەی سیاسەت و هێز و خۆشەویستیدا.",
    isFree: false,
    author: "لیگێند KRD",
    status: "ongoing"
  }
];

// Helper to generate chapters for a novel
export const getChaptersForNovel = (novelId: string): Chapter[] => {
  const isFree = NOVELS.find(n => n.id === novelId)?.isFree ?? false;
  const numChapters = 5;
  
  return Array.from({ length: numChapters }, (_, i) => {
    const chapterNumber = i + 1;
    // First 2 chapters are always free
    const coinCost = isFree || chapterNumber <= 2 ? 0 : 5 + Math.floor(Math.random() * 10);
    
    return {
      id: `${novelId}-ch${chapterNumber}`,
      novelId,
      chapterNumber,
      title: `بەشی ${chapterNumber}`,
      content: `ئەمە ناوەڕۆکی بەشی ${chapterNumber}یە بۆ ڕۆمانی ${novelId}. چیرۆکەکە لێرەدا دەست پێدەکات و ڕووداوەکان بەرەو پێش دەچن. پاڵەوانەکە ڕووبەڕووی ئاستەنگی نوێ دەبێتەوە... بەردەوامە. \n\n (ئەمە تەنها تێکستێکی تاقیکارییە بۆ نیشاندانی شێوازی خوێندنەوەی مانگا و نۆڤێلەکە لە ئەپڵیکەیشنەکەدا. دەتوانیت بۆ خوارەوە سکڕۆڵ بکەیت.) \n\n ە ڕووداوێکی نەچاوەڕوانکراودا، ئاسمان ڕەنگی گۆڕا و دەنگێکی گەورە هەموو ناوچەکەی هەژاند. خەڵکەکە بە ترسەوە سەیری ئاسمانیان دەکرد... \n\n دوای چەند خولەکێک، هەموو شتێک گەڕایەوە دۆخی ئاسایی، بەڵام هیچ کەس نەیئەزانی کە ئەمە تەنها سەرەتایە بۆ ڕووداوێکی زۆر گەورەتر...`,
      coinCost
    };
  });
};
