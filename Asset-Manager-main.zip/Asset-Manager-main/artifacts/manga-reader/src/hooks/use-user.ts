import { useState, useEffect, useCallback } from 'react';

export interface ReadingHistoryItem {
  novelId: string;
  chapterId: string;
  progress: number; // 0 to 1
  lastRead: number; // timestamp
}

export interface UserState {
  coins: number;
  adCount: number;
  lastAdTime: number;
  readingHistory: ReadingHistoryItem[];
  unlockedChapters: string[]; // array of chapter IDs
}

const DEFAULT_STATE: UserState = {
  coins: 50,
  adCount: 0,
  lastAdTime: 0,
  readingHistory: [],
  unlockedChapters: []
};

const STORAGE_KEY = 'manga_reader_user_state';
const MAX_ADS_PER_DAY = 15;
const COINS_PER_AD = 5;
const MS_PER_DAY = 24 * 60 * 60 * 1000;

export function useUser() {
  const [userState, setUserState] = useState<UserState>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Failed to parse user state", e);
    }
    return DEFAULT_STATE;
  });

  // Save to local storage whenever state changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userState));
  }, [userState]);

  // Reset ad count if 24 hours have passed since first ad watch
  useEffect(() => {
    const now = Date.now();
    if (userState.adCount > 0 && userState.lastAdTime > 0) {
      if (now - userState.lastAdTime > MS_PER_DAY) {
        setUserState(prev => ({
          ...prev,
          adCount: 0,
          lastAdTime: 0 // Reset time so the next ad watch starts a new 24h window
        }));
      }
    }
  }, [userState.adCount, userState.lastAdTime]);

  const watchAd = useCallback((): Promise<{ success: boolean; message: string; coinsEarned: number }> => {
    return new Promise((resolve) => {
      const now = Date.now();
      
      if (userState.adCount >= MAX_ADS_PER_DAY) {
        resolve({
          success: false,
          message: "سنووری سەیرکردنی ڕیکلام بۆ ئەمڕۆ تەواو بووە. تکایە سبەینێ دووبارە هەوڵ بدەرەوە.",
          coinsEarned: 0
        });
        return;
      }

      // First ad in the window sets the time
      const newLastAdTime = userState.adCount === 0 ? now : userState.lastAdTime;

      setUserState(prev => ({
        ...prev,
        coins: prev.coins + COINS_PER_AD,
        adCount: prev.adCount + 1,
        lastAdTime: newLastAdTime
      }));

      resolve({
        success: true,
        message: `سەرکەوتوو بوو! ${COINS_PER_AD} کۆینت بەدەستهێنا.`,
        coinsEarned: COINS_PER_AD
      });
    });
  }, [userState.adCount, userState.lastAdTime]);

  const buyCoins = useCallback((amount: number) => {
    setUserState(prev => ({
      ...prev,
      coins: prev.coins + amount
    }));
  }, []);

  const unlockChapter = useCallback((chapterId: string, cost: number): boolean => {
    if (userState.coins >= cost && !userState.unlockedChapters.includes(chapterId)) {
      setUserState(prev => ({
        ...prev,
        coins: prev.coins - cost,
        unlockedChapters: [...prev.unlockedChapters, chapterId]
      }));
      return true;
    }
    return false;
  }, [userState.coins, userState.unlockedChapters]);

  const hasUnlocked = useCallback((chapterId: string): boolean => {
    return userState.unlockedChapters.includes(chapterId);
  }, [userState.unlockedChapters]);

  const saveReadingProgress = useCallback((novelId: string, chapterId: string, progress: number) => {
    setUserState(prev => {
      const history = [...prev.readingHistory];
      const existingIndex = history.findIndex(h => h.novelId === novelId);
      
      const newItem: ReadingHistoryItem = {
        novelId,
        chapterId,
        progress,
        lastRead: Date.now()
      };

      if (existingIndex >= 0) {
        history[existingIndex] = newItem;
      } else {
        history.push(newItem);
      }

      // Sort by recently read
      history.sort((a, b) => b.lastRead - a.lastRead);

      return {
        ...prev,
        readingHistory: history
      };
    });
  }, []);

  const getProgress = useCallback((novelId: string) => {
    return userState.readingHistory.find(h => h.novelId === novelId);
  }, [userState.readingHistory]);

  return {
    user: userState,
    watchAd,
    buyCoins,
    unlockChapter,
    hasUnlocked,
    saveReadingProgress,
    getProgress,
    canWatchAd: userState.adCount < MAX_ADS_PER_DAY,
    remainingAds: Math.max(0, MAX_ADS_PER_DAY - userState.adCount)
  };
}
