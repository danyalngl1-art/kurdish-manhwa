import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { NOVELS } from "@/data/catalog";
import { Search, Filter } from "lucide-react";

const GENRES = [
  { id: "all", label: "هەمووی" },
  { id: "action", label: "ئاکشن" },
  { id: "romance", label: "ڕۆمانسی" },
  { id: "fantasy", label: "فانتازیا" },
  { id: "drama", label: "دراما" },
  { id: "horror", label: "ترسناک" }
];

export default function Browse() {
  const [activeGenre, setActiveGenre] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredNovels = NOVELS.filter(novel => {
    const matchesGenre = activeGenre === "all" || novel.genre === activeGenre;
    const matchesSearch = novel.title.includes(searchQuery) || novel.author.includes(searchQuery);
    return matchesGenre && matchesSearch;
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-4 pt-8 pb-24"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <h1 className="text-3xl font-black text-white mb-2">کتێبخانە</h1>
          <p className="text-muted-foreground">گەڕان بەدوای دڵخوازترین مانگا و نۆڤێلەکانت بکە</p>
        </div>

        <div className="w-full md:w-auto flex flex-col sm:flex-row gap-3">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input 
              type="text"
              placeholder="گەڕان..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 bg-card border border-border rounded-lg py-2 pr-10 pl-4 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
            />
          </div>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-4 mb-8 scrollbar-hide no-scrollbar">
        {GENRES.map(genre => (
          <button
            key={genre.id}
            onClick={() => setActiveGenre(genre.id)}
            className={`whitespace-nowrap px-5 py-2 rounded-full text-sm font-medium transition-all ${
              activeGenre === genre.id 
                ? 'bg-primary text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]' 
                : 'bg-card border border-border text-muted-foreground hover:text-white hover:border-gray-500'
            }`}
          >
            {genre.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
        {filteredNovels.length > 0 ? (
          filteredNovels.map((novel, i) => (
            <motion.div
              key={novel.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="h-full"
            >
              <Link href={`/novel/${novel.id}`}>
                <div className="group cursor-pointer h-full flex flex-col">
                  <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 mb-3 flex-shrink-0">
                    <img 
                      src={novel.cover} 
                      alt={novel.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    {novel.isFree && (
                      <div className="absolute top-2 right-2 bg-green-500/90 text-white text-[10px] font-bold px-2 py-1 rounded-md backdrop-blur-sm">
                        خۆڕایی
                      </div>
                    )}
                  </div>
                  <h3 className="font-bold text-white text-base group-hover:text-primary transition-colors line-clamp-1">{novel.title}</h3>
                  <p className="text-muted-foreground text-xs mt-1">{novel.author}</p>
                </div>
              </Link>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center flex flex-col items-center text-muted-foreground">
            <Filter className="w-12 h-12 mb-4 opacity-20" />
            <p>هیچ ئەنجامێک نەدۆزرایەوە</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
