import { useState } from "react";
import { motion } from "framer-motion";
import { Coins as CoinsIcon, Play, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { useUser } from "@/hooks/use-user";

export default function Coins() {
  const { user, watchAd, canWatchAd, remainingAds } = useUser();
  const [isWatching, setIsWatching] = useState(false);
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | null }>({ text: '', type: null });

  const handleWatchAd = async () => {
    if (!canWatchAd || isWatching) return;

    setIsWatching(true);
    setProgress(0);
    setMessage({ text: '', type: null });

    // Simulate ad watching for 3 seconds
    const duration = 3000;
    const interval = 50;
    const steps = duration / interval;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      setProgress((currentStep / steps) * 100);
      
      if (currentStep >= steps) {
        clearInterval(timer);
        finishAd();
      }
    }, interval);
  };

  const finishAd = async () => {
    const result = await watchAd();
    setIsWatching(false);
    setProgress(0);
    
    if (result.success) {
      setMessage({ text: result.message, type: 'success' });
    } else {
      setMessage({ text: result.message, type: 'error' });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto px-4 pt-12 pb-24"
    >
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center p-4 bg-secondary/10 rounded-full mb-4 glow-secondary">
          <CoinsIcon className="w-12 h-12 text-secondary" />
        </div>
        <h1 className="text-3xl font-black text-white mb-2">بەدەستهێنانی کۆین</h1>
        <p className="text-muted-foreground">کۆین بەدەست بهێنە بۆ خوێندنەوەی بەشە داخراوەکان</p>
      </div>

      <div className="bg-card border border-white/10 rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-2xl">
        {/* Glow effect behind the card */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-secondary/5 blur-[100px] pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          
          <div className="text-center mb-8">
            <p className="text-sm text-muted-foreground mb-1">کۆینی ئێستات</p>
            <div className="text-5xl font-black text-white flex items-center justify-center gap-3">
              <span>{user.coins}</span>
              <CoinsIcon className="w-8 h-8 text-secondary" />
            </div>
          </div>

          <div className="w-full max-w-sm bg-background/50 border border-white/5 rounded-xl p-4 mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-400">ڕیکلامی ماوە بۆ ئەمڕۆ</span>
              <span className="text-sm font-bold text-white bg-primary/20 text-primary px-2 py-0.5 rounded">{remainingAds} / 15</span>
            </div>
            <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-primary h-full rounded-full transition-all duration-500"
                style={{ width: `${(remainingAds / 15) * 100}%` }}
              />
            </div>
            {user.lastAdTime > 0 && !canWatchAd && (
              <div className="mt-4 flex items-center justify-center gap-2 text-yellow-500 text-sm bg-yellow-500/10 p-2 rounded-lg">
                <Clock className="w-4 h-4" />
                <span>دوای ٢٤ کاتژمێر نوێ دەبێتەوە</span>
              </div>
            )}
          </div>

          {isWatching ? (
            <div className="w-full max-w-sm text-center">
              <p className="text-primary font-medium mb-4 animate-pulse">سەیرکردنی ڕیکلام...</p>
              <div className="w-full bg-white/10 rounded-full h-4 overflow-hidden relative">
                <div 
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-secondary to-primary transition-all duration-75 ease-linear"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          ) : (
            <button
              onClick={handleWatchAd}
              disabled={!canWatchAd}
              className={`w-full max-w-sm flex items-center justify-center gap-3 py-4 rounded-xl font-bold text-lg transition-all ${
                canWatchAd 
                  ? 'bg-primary hover:bg-primary/90 text-white shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)]' 
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
            >
              <Play className={`w-6 h-6 ${canWatchAd ? 'fill-white' : 'fill-muted-foreground'}`} />
              <span>سەیرکردنی ڕیکلام (+٥ کۆین)</span>
            </button>
          )}

          {message.text && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-6 flex items-center gap-2 p-3 rounded-lg text-sm font-medium w-full max-w-sm ${
                message.type === 'success' 
                  ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                  : 'bg-red-500/10 text-red-400 border border-red-500/20'
              }`}
            >
              {message.type === 'success' ? <CheckCircle2 className="w-5 h-5 flex-shrink-0" /> : <AlertCircle className="w-5 h-5 flex-shrink-0" />}
              <span>{message.text}</span>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
