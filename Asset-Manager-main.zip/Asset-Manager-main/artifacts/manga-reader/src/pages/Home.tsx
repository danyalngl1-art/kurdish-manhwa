import { Link } from "wouter";
import { motion } from "framer-motion";
import { NOVELS } from "@/data/catalog";
import { Play, Sparkles, TrendingUp } from "lucide-react";

export default function Home() {
  const featured = NOVELS[0];
  const allTitles = NOVELS;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="w-full pb-20"
    >
      {/* Hero Section */}
      <div className="relative w-full h-[60vh] min-h-[400px] lg:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={featured.cover} 
            alt={featured.title} 
            className="w-full h-full object-cover object-top opacity-50 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-l from-background/90 via-transparent to-transparent" />
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 lg:px-24 max-w-7xl mx-auto flex flex-col items-start gap-4">
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-2 px-3 py-1 bg-primary/20 border border-primary/30 rounded-full text-primary text-sm font-medium glow-primary"
          >
            <Sparkles className="w-4 h-4" />
            <span>نوێترین</span>
          </motion.div>
          
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-6xl font-black text-white text-glow"
          >
            {featured.title}
          </motion.h1>
          
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-gray-300 max-w-xl text-lg line-clamp-3 leading-relaxed"
          >
            {featured.description}
          </motion.p>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-4"
          >
            <Link href={`/novel/${featured.id}`}>
              <div className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-lg font-bold transition-all shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)] cursor-pointer">
                <Play className="w-5 h-5 fill-white" />
                خوێندنەوە
              </div>
            </Link>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-12">
        <section>
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-6 h-6 text-primary" />
            <h2 className="text-2xl font-bold text-white">مانهواکان</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {allTitles.map((novel, i) => (
              <motion.div
                key={novel.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
              >
                <Link href={`/novel/${novel.id}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 mb-3">
                      <img
                        src={novel.cover}
                        alt={novel.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      {novel.isFree && (
                        <div className="absolute top-2 right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-md">
                          خۆڕایی
                        </div>
                      )}
                    </div>
                    <h3 className="font-bold text-white text-base group-hover:text-primary transition-colors line-clamp-1">{novel.title}</h3>
                    <p className="text-muted-foreground text-sm">{novel.author}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </motion.div>
  );
}
