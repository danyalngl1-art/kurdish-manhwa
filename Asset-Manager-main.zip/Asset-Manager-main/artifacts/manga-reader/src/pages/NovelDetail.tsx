import { useState, useMemo } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Play, ArrowRight, Lock, Unlock, Clock, Star, Coins } from "lucide-react";
import { NOVELS, getChaptersForNovel } from "@/data/catalog";
import { useUser } from "@/hooks/use-user";
import { toast } from "sonner";

export default function NovelDetail() {
  const [, params] = useRoute("/novel/:id");
  const [, setLocation] = useLocation();
  const { user, unlockChapter, hasUnlocked, getProgress } = useUser();
  const [unlockModal, setUnlockModal] = useState<{ isOpen: boolean; chapterId: string; cost: number; title: string } | null>(null);

  const novel = useMemo(() => NOVELS.find(n => n.id === params?.id), [params?.id]);
  const chapters = useMemo(() => novel ? getChaptersForNovel(novel.id) : [], [novel]);
  const progress = useMemo(() => novel ? getProgress(novel.id) : null, [novel, getProgress]);

  if (!novel) return <div className="p-10 text-center text-white">نەدۆزرایەوە</div>;

  const firstChapter = chapters[0];
  const lastReadChapter = progress ? chapters.find(c => c.id === progress.chapterId) : null;
  const continueChapter = lastReadChapter || firstChapter;

  const handleChapterClick = (chapter: typeof chapters[0]) => {
    if (chapter.coinCost === 0 || hasUnlocked(chapter.id)) {
      setLocation(`/read/${novel.id}/${chapter.id}`);
    } else {
      setUnlockModal({
        isOpen: true,
        chapterId: chapter.id,
        cost: chapter.coinCost,
        title: chapter.title
      });
    }
  };

  const handleUnlock = () => {
    if (!unlockModal) return;

    if (user.coins < unlockModal.cost) {
      toast.error("کۆینی پێویستت نییە", { 
        description: "تکایە ڕیکلام سەیر بکە بۆ بەدەستهێنانی کۆین",
        action: { label: "بەدەستهێنان", onClick: () => setLocation('/coins') }
      });
      return;
    }

    const success = unlockChapter(unlockModal.chapterId, unlockModal.cost);
    if (success) {
      toast.success("بەشەکە کرایەوە!", { description: "ئێستا دەتوانیت بیخوێنیتەوە" });
      setUnlockModal(null);
      // Optional: automatically navigate
      // setLocation(`/read/${novel.id}/${unlockModal.chapterId}`);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="w-full pb-24"
    >
      {/* Top Banner */}
      <div className="relative h-[40vh] min-h-[300px] w-full">
        <div className="absolute inset-0">
          <img src={novel.cover} className="w-full h-full object-cover blur-md opacity-30" alt="" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
        
        {/* Back Button */}
        <div className="absolute top-4 right-4 z-10 md:top-6 md:right-6">
          <Link href="/novels">
            <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center border border-white/10 cursor-pointer hover:bg-black/60 transition-colors">
              <ArrowRight className="w-5 h-5 text-white" />
            </div>
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-6 md:gap-8 items-center md:items-start text-center md:text-right">
          
          {/* Cover */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-48 md:w-56 shrink-0 aspect-[2/3] rounded-xl overflow-hidden border-2 border-white/10 shadow-2xl glow-primary bg-card"
          >
            <img src={novel.cover} alt={novel.title} className="w-full h-full object-cover" />
          </motion.div>

          {/* Info */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="flex-grow pt-4 md:pt-12"
          >
            <div className="flex items-center justify-center md:justify-start gap-2 mb-3">
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300 border border-white/10">
                {novel.genre === 'action' ? 'ئاکشن' :
                 novel.genre === 'romance' ? 'ڕۆمانسی' :
                 novel.genre === 'fantasy' ? 'فانتازیا' :
                 novel.genre === 'drama' ? 'دراما' : 'ترسناک'}
              </span>
              <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-gray-300 border border-white/10 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {novel.status === 'ongoing' ? 'بەردەوامە' : 'تەواوبووە'}
              </span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-black text-white mb-2">{novel.title}</h1>
            <p className="text-primary font-medium mb-4">{novel.author}</p>
            
            <p className="text-gray-300 leading-relaxed text-sm md:text-base mb-6 max-w-2xl">
              {novel.description}
            </p>

            {/* Read Button */}
            {continueChapter && (
              <button 
                onClick={() => handleChapterClick(continueChapter)}
                className="w-full md:w-auto flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-lg font-bold transition-all shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)]"
              >
                <Play className="w-5 h-5 fill-white" />
                {progress ? 'بەردەوام بە لە خوێندنەوە' : 'دەستبکە بە خوێندنەوە'}
              </button>
            )}
          </motion.div>
        </div>

        {/* Chapters List */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-16"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">بەشەکان</h2>
            <span className="text-muted-foreground text-sm">{chapters.length} بەش</span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {chapters.map((chapter) => {
              const isFree = chapter.coinCost === 0;
              const isUnlocked = hasUnlocked(chapter.id);
              const canRead = isFree || isUnlocked;
              const isLastRead = progress?.chapterId === chapter.id;

              return (
                <div 
                  key={chapter.id}
                  onClick={() => handleChapterClick(chapter)}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all cursor-pointer ${
                    isLastRead ? 'bg-primary/10 border-primary/50' :
                    'bg-card border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                      canRead ? 'bg-primary/20 text-primary' : 'bg-white/5 text-muted-foreground'
                    }`}>
                      <span className="font-bold text-sm">{chapter.chapterNumber}</span>
                    </div>
                    <div>
                      <h3 className={`font-bold ${isLastRead ? 'text-primary' : 'text-white'}`}>{chapter.title}</h3>
                      {isLastRead && <span className="text-xs text-primary">دواین جار خوێندراوەتەوە</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {!canRead ? (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-lg text-yellow-500">
                        <Lock className="w-4 h-4" />
                        <span className="text-sm font-bold">{chapter.coinCost}</span>
                      </div>
                    ) : (
                      isFree ? (
                        <span className="text-xs font-bold text-green-400 bg-green-500/10 px-2 py-1 rounded">خۆڕایی</span>
                      ) : (
                        <span className="text-xs text-muted-foreground bg-white/5 px-2 py-1 rounded flex items-center gap-1">
                          <Unlock className="w-3 h-3" />
                          کراوەتەوە
                        </span>
                      )
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Unlock Modal */}
      <AnimatePresence>
        {unlockModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setUnlockModal(null)}
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative bg-card border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
              
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">کردنەوەی بەش</h3>
                <p className="text-muted-foreground text-sm">
                  ئایا دەتەوێت <span className="text-white">{unlockModal.title}</span> بکەیتەوە؟
                </p>
              </div>

              <div className="flex justify-between items-center bg-background/50 p-4 rounded-xl border border-white/5 mb-6">
                <span className="text-sm text-gray-400">تێچوو:</span>
                <div className="flex items-center gap-1.5 font-bold text-yellow-500">
                  <Coins className="w-4 h-4" />
                  <span>{unlockModal.cost}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <button 
                  onClick={handleUnlock}
                  className="w-full py-3 bg-primary hover:bg-primary/90 text-white rounded-lg font-bold transition-colors"
                >
                  کردنەوە
                </button>
                <button 
                  onClick={() => setUnlockModal(null)}
                  className="w-full py-3 bg-white/5 hover:bg-white/10 text-white rounded-lg font-medium transition-colors"
                >
                  پاشگەزبوونەوە
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
