import { Link } from "wouter";
import { motion } from "framer-motion";
import { User as UserIcon, Coins, History, ChevronLeft, BookOpen } from "lucide-react";
import { useUser } from "@/hooks/use-user";
import { NOVELS } from "@/data/catalog";

export default function Profile() {
  const { user } = useUser();

  // Get reading history with novel details
  const historyWithDetails = user.readingHistory
    .map(historyItem => {
      const novel = NOVELS.find(n => n.id === historyItem.novelId);
      return { ...historyItem, novel };
    })
    .filter(item => item.novel) // Remove items where novel no longer exists
    .slice(0, 10); // Show max 10

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-3xl mx-auto px-4 pt-12 pb-24"
    >
      <div className="flex flex-col items-center mb-12">
        <div className="w-24 h-24 bg-card border-2 border-primary/50 rounded-full flex items-center justify-center mb-4 glow-primary overflow-hidden">
          <UserIcon className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-1">خوێنەری ئازیز</h1>
        <p className="text-muted-foreground text-sm">بەخێربێیت بۆ هەژمارەکەت</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-card border border-white/5 rounded-2xl p-5 flex flex-col items-center text-center">
          <div className="bg-secondary/10 p-3 rounded-full mb-3">
            <Coins className="w-6 h-6 text-secondary" />
          </div>
          <p className="text-muted-foreground text-xs mb-1">کۆینەکانت</p>
          <p className="text-2xl font-black text-white">{user.coins}</p>
        </div>
        
        <div className="bg-card border border-white/5 rounded-2xl p-5 flex flex-col items-center text-center">
          <div className="bg-primary/10 p-3 rounded-full mb-3">
            <BookOpen className="w-6 h-6 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs mb-1">بەشە کڕدراوەکان</p>
          <p className="text-2xl font-black text-white">{user.unlockedChapters.length}</p>
        </div>
      </div>

      <div className="bg-card border border-white/5 rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-white/5 flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          <h2 className="font-bold text-lg text-white">مێژووی خوێندنەوە</h2>
        </div>
        
        <div className="divide-y divide-white/5">
          {historyWithDetails.length > 0 ? (
            historyWithDetails.map((item) => (
              <Link key={`${item.novelId}-${item.chapterId}`} href={`/novel/${item.novelId}`}>
                <div className="flex items-center gap-4 p-4 hover:bg-white/5 transition-colors cursor-pointer group">
                  <div className="w-12 h-16 rounded-md overflow-hidden flex-shrink-0">
                    <img 
                      src={item.novel!.cover} 
                      alt={item.novel!.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    />
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-bold text-white text-sm line-clamp-1">{item.novel!.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-primary bg-primary/10 px-2 py-0.5 rounded">
                        بەشی خێندراوە
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(item.lastRead).toLocaleDateString('ku-IQ')}
                      </span>
                    </div>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </Link>
            ))
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-20" />
              <p>هیچ مێژوویەکی خوێندنەوە نییە</p>
              <Link href="/novels">
                <span className="text-primary hover:underline mt-2 inline-block cursor-pointer text-sm">دەستبکە بە خوێندنەوە</span>
              </Link>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
