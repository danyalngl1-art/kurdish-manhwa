import { useState, useEffect, useMemo, useRef } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Settings, ChevronLeft, ChevronRight, List } from "lucide-react";
import { NOVELS, getChaptersForNovel } from "@/data/catalog";
import { useUser } from "@/hooks/use-user";

export default function Reader() {
  const [, params] = useRoute("/read/:id/:chapter");
  const [, setLocation] = useLocation();
  const { saveReadingProgress } = useUser();
  const [controlsVisible, setControlsVisible] = useState(true);
  const [fontSize, setFontSize] = useState("text-xl");
  
  const scrollRef = useRef<HTMLDivElement>(null);

  const novel = useMemo(() => NOVELS.find(n => n.id === params?.id), [params?.id]);
  const chapters = useMemo(() => novel ? getChaptersForNovel(novel.id) : [], [novel]);
  
  const currentChapterIndex = useMemo(() => {
    return chapters.findIndex(c => c.id === params?.chapter);
  }, [chapters, params?.chapter]);

  const currentChapter = chapters[currentChapterIndex];
  const prevChapter = currentChapterIndex > 0 ? chapters[currentChapterIndex - 1] : null;
  const nextChapter = currentChapterIndex < chapters.length - 1 ? chapters[currentChapterIndex + 1] : null;

  // Save progress when loading a chapter
  useEffect(() => {
    if (novel && currentChapter) {
      saveReadingProgress(novel.id, currentChapter.id, 0);
    }
  }, [novel, currentChapter, saveReadingProgress]);

  // Hide controls on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (controlsVisible) {
        setControlsVisible(false);
      }
    };
    
    const scrollEl = scrollRef.current;
    if (scrollEl) {
      scrollEl.addEventListener('scroll', handleScroll, { passive: true });
      return () => scrollEl.removeEventListener('scroll', handleScroll);
    }
  }, [controlsVisible]);

  if (!novel || !currentChapter) return <div className="fixed inset-0 bg-background z-[100] flex items-center justify-center text-white">نەدۆزرایەوە</div>;

  return (
    <div className="fixed inset-0 bg-background z-[100] flex flex-col font-sans">
      {/* Content Area */}
      <div 
        ref={scrollRef}
        onClick={() => setControlsVisible(!controlsVisible)}
        className="flex-grow overflow-y-auto w-full px-4 sm:px-8 py-20 text-right leading-loose scroll-smooth"
      >
        <div className="max-w-2xl mx-auto min-h-[101%]">
          <h1 className="text-3xl md:text-4xl font-black text-white mb-12 mt-8 text-center">{currentChapter.title}</h1>
          <div className={`${fontSize} text-gray-300 space-y-8 whitespace-pre-wrap`}>
            {currentChapter.content}
          </div>
          
          <div className="mt-20 border-t border-white/10 pt-10 text-center text-muted-foreground pb-20">
            <p>کۆتایی {currentChapter.title}</p>
          </div>
        </div>
      </div>

      {/* Floating Header */}
      <AnimatePresence>
        {controlsVisible && (
          <motion.div 
            initial={{ y: "-100%" }}
            animate={{ y: 0 }}
            exit={{ y: "-100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute top-0 left-0 right-0 h-16 bg-background/90 backdrop-blur-md border-b border-white/10 px-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <Link href={`/novel/${novel.id}`}>
                <div className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer">
                  <ArrowRight className="w-6 h-6 text-white" />
                </div>
              </Link>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-white line-clamp-1">{novel.title}</span>
                <span className="text-xs text-muted-foreground line-clamp-1">{currentChapter.title}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setFontSize(prev => prev === 'text-xl' ? 'text-2xl' : prev === 'text-2xl' ? 'text-lg' : 'text-xl');
                }}
                className="p-2 hover:bg-white/10 rounded-full transition-colors text-white"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Footer */}
      <AnimatePresence>
        {controlsVisible && (
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute bottom-0 left-0 right-0 h-20 bg-background/90 backdrop-blur-md border-t border-white/10 px-4 flex items-center justify-between max-w-2xl mx-auto lg:rounded-t-2xl lg:border-x lg:border-white/10"
          >
            <button 
              onClick={(e) => {
                e.stopPropagation();
                if (nextChapter) setLocation(`/novel/${novel.id}`); // They need to unlock from detail page if locked
              }}
              disabled={!nextChapter}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                nextChapter ? 'text-white hover:bg-white/10' : 'text-white/20 cursor-not-allowed'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
              <span>دواتر</span>
            </button>

            <Link href={`/novel/${novel.id}`}>
              <div className="p-3 hover:bg-white/10 rounded-full transition-colors text-white cursor-pointer">
                <List className="w-6 h-6" />
              </div>
            </Link>

            <button 
              onClick={(e) => {
                e.stopPropagation();
                if (prevChapter) setLocation(`/read/${novel.id}/${prevChapter.id}`);
              }}
              disabled={!prevChapter}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                prevChapter ? 'text-white hover:bg-white/10' : 'text-white/20 cursor-not-allowed'
              }`}
            >
              <span>پێشتر</span>
              <ChevronLeft className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
