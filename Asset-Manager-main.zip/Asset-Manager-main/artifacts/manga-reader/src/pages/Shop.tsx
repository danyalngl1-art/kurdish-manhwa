import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag, Play, AlertCircle, CheckCircle2, Clock, Crown } from "lucide-react";
import { useUser } from "@/hooks/use-user";

const COIN_PACKAGES = [
  { coins: 100, price: 2, label: "١٠٠ کۆین", desc: "بۆ کردنەوەی چابتری قفڵکراو" },
  { coins: 500, price: 8, label: "٥٠٠ کۆین", desc: "پاشەکەوتی باشتر" },
  { coins: 1000, price: 15, label: "١٠٠٠ کۆین", desc: "پۆکی بەڕێوەبردن" },
  { coins: 2000, price: 25, label: "٢٠٠٠ کۆین", desc: "پۆکی تایبەت" },
  { coins: 8000, price: 90, label: "٨٠٠٠ کۆین", desc: "گەورەترین پۆکی کۆین" },
];

const PRIME_PACKAGES = [
  { label: "پڕایمی هەفتانە", desc: "سوودمەندبوون لە سەرجەم تایبەتمەندییەکان", price: 1.5 },
  { label: "پڕایمی مانگانە", desc: "بۆ ماوەی یەک مانگ", price: 5 },
  { label: "پڕایمی ٣ مانگی", desc: "پاشەکەوتکردن", price: 12 },
  { label: "پڕایمی ٦ مانگی", desc: "تایبەتمەندی پێشکەوتوو", price: 40 },
];

export default function Shop() {
  const { user, watchAd, canWatchAd, remainingAds, buyCoins } = useUser();
  const [isWatching, setIsWatching] = useState(false);
  const [adProgress, setAdProgress] = useState(0);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" | null }>({ text: "", type: null });

  const handleBuyCoins = (coins: number, price: number) => {
    buyCoins(coins);
    setMessage({ text: `سەرکەوتوو بوو! ${coins} کۆین بۆ هەژمارەکەت زیادکرا.`, type: "success" });
    setTimeout(() => setMessage({ text: "", type: null }), 4000);
  };

  const handlePrime = (label: string) => {
    setMessage({ text: `${label} هەڵبژێردرا. بەخێربێیت!`, type: "success" });
    setTimeout(() => setMessage({ text: "", type: null }), 4000);
  };

  const handleWatchAd = () => {
    if (!canWatchAd || isWatching) return;
    setIsWatching(true);
    setAdProgress(0);
    setMessage({ text: "", type: null });

    const duration = 3000;
    const interval = 50;
    const steps = duration / interval;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      setAdProgress((currentStep / steps) * 100);
      if (currentStep >= steps) {
        clearInterval(timer);
        finishAd();
      }
    }, interval);
  };

  const finishAd = async () => {
    const result = await watchAd();
    setIsWatching(false);
    setAdProgress(0);
    setMessage({ text: result.message, type: result.success ? "success" : "error" });
    setTimeout(() => setMessage({ text: "", type: null }), 5000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto px-4 pt-10 pb-28"
    >
      {/* Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-4">
          <ShoppingBag className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-3xl font-black text-white mb-1">پەخشی مانهوا و وەرگێڕانی کوردی</h1>
        <div className="inline-flex items-center gap-2 bg-[#262626] border border-primary/30 px-4 py-1.5 rounded-full mt-3">
          <span className="text-sm">🪙</span>
          <span className="font-bold text-primary text-sm">کۆینی ئێستا: {user.coins}</span>
        </div>
      </div>

      {/* Global message */}
      <AnimatePresence>
        {message.text && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`flex items-center gap-2 p-3 rounded-xl text-sm font-medium mb-6 ${
              message.type === "success"
                ? "bg-green-500/10 text-green-400 border border-green-500/20"
                : "bg-red-500/10 text-red-400 border border-red-500/20"
            }`}
          >
            {message.type === "success" ? (
              <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
            )}
            <span>{message.text}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Coin Packages --- */}
      <div className="bg-[#1a1a1a] border border-[#333] rounded-xl p-6 mb-8">
        <h2 className="text-xl font-bold text-primary mb-1">بازاڕی کڕین (Shop)</h2>
        <h3 className="text-white font-semibold mb-5 text-sm opacity-80">📦 کڕینی کۆین</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {COIN_PACKAGES.map((pkg) => (
            <div
              key={pkg.coins}
              className="bg-[#222] border border-[#444] rounded-lg p-5 flex flex-col justify-between hover:border-primary/50 transition-colors"
            >
              <div>
                <h3 className="text-primary font-bold text-lg mb-1">{pkg.label}</h3>
                <p className="text-gray-400 text-sm mb-3">{pkg.desc}</p>
                <p className="text-white font-bold text-lg mb-4">${pkg.price}.00</p>
              </div>
              <button
                onClick={() => handleBuyCoins(pkg.coins, pkg.price)}
                className="w-full bg-primary text-[#121212] font-bold py-2 rounded-md hover:bg-primary/85 transition-colors text-sm"
              >
                کڕین
              </button>
            </div>
          ))}
        </div>

        {/* --- Prime Packages --- */}
        <h3 className="text-white font-semibold mb-5 mt-8 text-sm opacity-80 flex items-center gap-2">
          <Crown className="w-4 h-4 text-primary" />
          پاکێجەکانی پڕایم (Prime)
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {PRIME_PACKAGES.map((pkg) => (
            <div
              key={pkg.label}
              className="bg-[#222] border border-[#444] rounded-lg p-5 flex flex-col justify-between hover:border-primary/50 transition-colors"
            >
              <div>
                <h3 className="text-primary font-bold text-base mb-1">{pkg.label}</h3>
                <p className="text-gray-400 text-sm mb-3">{pkg.desc}</p>
                <p className="text-white font-bold text-lg mb-4">${pkg.price.toFixed(2)}</p>
              </div>
              <button
                onClick={() => handlePrime(pkg.label)}
                className="w-full bg-primary text-[#121212] font-bold py-2 rounded-md hover:bg-primary/85 transition-colors text-sm"
              >
                بەشداریکردن
              </button>
            </div>
          ))}
        </div>
        <p className="text-center text-gray-500 text-xs mt-4">
          * تێبینی: پڕایمی ساڵانە پارەی نییە و تەنها لە ڕێگەی پێشبڕکێی مانگانەی خوێنەرانەوە دەستدەکەوێت (بۆ ئەوانەی پڕایم نین)!
        </p>
      </div>

      {/* --- Free Coins via Ad --- */}
      <div className="bg-[#1a1a1a] border border-[#333] rounded-xl p-6 text-center">
        <h2 className="text-xl font-bold text-primary mb-2">بەدەستهێنانی کۆین بە ڕیکلام</h2>
        <p className="text-gray-400 text-sm mb-6">
          سەیری ڕیکلام بکە و ٥ کۆین بەدەست بهێنە (سنووری ١٥ جار لە ٢٤ کاتژمێردا).
        </p>

        {/* Daily limit progress */}
        <div className="max-w-sm mx-auto bg-[#222] border border-[#444] rounded-xl p-4 mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-400">ڕیکلامی ماوە بۆ ئەمڕۆ</span>
            <span className="text-sm font-bold text-primary bg-primary/10 px-2 py-0.5 rounded">
              {remainingAds} / 15
            </span>
          </div>
          <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
            <div
              className="bg-primary h-full rounded-full transition-all duration-500"
              style={{ width: `${(remainingAds / 15) * 100}%` }}
            />
          </div>
          {!canWatchAd && (
            <div className="mt-4 flex items-center justify-center gap-2 text-yellow-500 text-sm bg-yellow-500/10 p-2 rounded-lg">
              <Clock className="w-4 h-4" />
              <span>دوای ٢٤ کاتژمێر نوێ دەبێتەوە</span>
            </div>
          )}
        </div>

        {isWatching ? (
          <div className="max-w-sm mx-auto">
            <p className="text-primary font-medium mb-4 animate-pulse">سەیرکردنی ڕیکلام...</p>
            <div className="w-full bg-white/10 rounded-full h-4 overflow-hidden relative">
              <div
                className="absolute top-0 left-0 h-full bg-primary transition-all duration-75 ease-linear"
                style={{ width: `${adProgress}%` }}
              />
            </div>
          </div>
        ) : (
          <button
            onClick={handleWatchAd}
            disabled={!canWatchAd}
            className={`inline-flex items-center justify-center gap-3 px-8 py-3 rounded-lg font-bold text-base transition-all ${
              canWatchAd
                ? "bg-primary text-[#121212] hover:bg-primary/85"
                : "bg-[#333] text-gray-500 cursor-not-allowed"
            }`}
          >
            <Play className="w-5 h-5 fill-current" />
            سەیرکردنی ڕیکلام (+5 کۆین)
          </button>
        )}
      </div>
    </motion.div>
  );
}
